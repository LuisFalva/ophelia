class OpheliaStudio:
    pass
