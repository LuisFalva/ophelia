from math import log
from ophelia.spark.utils.logger import OpheliaLogger


class OpheliaMetrics:

    __logger = OpheliaLogger()


