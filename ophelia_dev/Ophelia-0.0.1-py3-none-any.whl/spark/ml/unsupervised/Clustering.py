class KMeansCluster:
    """
    traditional spark clustering
    """


class FuzzyClusterMeans:
    """
    FuzzyCMeans in mllib
    """


class BisectingKM:
    """
    traditional spark clustering
    """


class GaussianM:
    """
    traditional spark clustering
    """


class LatentDirichlet:
    """
    traditional spark clustering
    """


class ClusterFeatureTree:
    """
    BIRCH algorithm
    """


class HierarchicalCluster:
    """
    SparkPinkMST
    """


class HiddenMarkov:
    """
    SparkPinkMST
    """

