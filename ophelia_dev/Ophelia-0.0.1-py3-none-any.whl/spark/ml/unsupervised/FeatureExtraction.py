import numpy as np
from typing import Dict
from pyspark.sql import DataFrame
from pyspark.sql.functions import monotonically_increasing_id
from pyspark.ml import Transformer
from pyspark.ml.feature import StandardScaler, PCA
from pyspark.mllib.util import MLUtils
from pyspark.mllib.linalg.distributed import IndexedRowMatrix, IndexedRow
from ophelia.spark.ml.feature_miner import FeatureMiner
from ophelia.spark.utils.logger import OpheliaLogger


class PrincipleComponent:
    """
    for PCA algorithm
    """


class SingularValueDecomposition(Transformer):
    """
    for SVD algorithm
    """
    def __init__(self, k: int = None, offset: float = 0.95):
        super().__init__()
        self.__logger = OpheliaLogger()
        self.k = k
        self.offset = offset
        self.vec_df = None
        self.vec_scale_df = None

    def __assembling_features(self, df: DataFrame) -> DataFrame:
        vector_assemble_df = FeatureMiner.build_vector_assembler(df=df, input_cols=df.columns)
        self.__logger.info(f"Feature Vector Assembling")
        return vector_assemble_df.select('features', monotonically_increasing_id().alias('id'))

    def __normalize_features(self, df: DataFrame, with_mean: bool = True, with_std: bool = True) -> DataFrame:
        self.vec_df = self.__assembling_features(df)
        std_scaler = StandardScaler(
            withMean=with_mean, withStd=with_std, inputCol='features', outputCol='scaled_features'
        )
        self.__logger.info("Feature Standard Normalization")
        return std_scaler.fit(self.vec_df).transform(self.vec_df)

    def __index_row_matrix_rdd(self, df: DataFrame) -> IndexedRowMatrix:
        self.vec_scale_df = self.__normalize_features(df)
        vector_mllib = MLUtils.convertVectorColumnsFromML(self.vec_scale_df, 'scaled_features').drop('features')
        self.__logger.info(f"Indexing RDD Row Matrix")
        return IndexedRowMatrix(vector_mllib.select('scaled_features', 'id').rdd.map(lambda x: IndexedRow(x[1], x[0])))

    @staticmethod
    def __find_k(var_array: np.ndarray, offset: float = 0.95) -> np.int64:
        return np.argmax(var_array > offset) + 1

    def __compute_svd(self, df: DataFrame, compute_u: bool = True) -> Dict:
        k, d = self.k, len(df.columns)
        if k is None:
            k = d
            self.__logger.warning(f"Warning: Set 'K' as d={k} since parameter is not specified")
        svd = self.__index_row_matrix_rdd(df).computeSVD(k=k, computeU=compute_u)
        tape_message = f"| Compute SVD With K={k}, d={d}, n={self.vec_df.count()} |"
        self.__logger.tape(tape_message, adjust_tape=2)
        self.__logger.warning(tape_message)
        self.__logger.tape(tape_message, adjust_tape=2)
        return {'svd': svd, 'U': svd.U, 'S': svd.s.toArray(), 'V': svd.V, 'n': self.vec_df.count(), 'd': d}

    def __compute_pc(self, df: DataFrame) -> Dict:
        svd = self.__compute_svd(df)
        eigen_val = np.flipud(np.sort(svd['S']**2 / (svd['n']-1)))
        tot_var = eigen_val.cumsum() / eigen_val.sum()
        k_pc = self.__find_k(tot_var, offset=self.offset)
        compute_u = svd['U'].rows.map(lambda x: (x.index, x.vector[0:k_pc] * svd['S'][0:k_pc]))
        tape_message = (
            lambda variance:
            f"| Components Over {variance} Of The Variance k={self.__find_k(tot_var, offset=variance)} |"
        )
        self.__logger.info(f"Compute Variance For Each Component")
        self.__logger.tape(tape_message(variance=0.0))
        self.__logger.warning(tape_message(variance=0.75))
        self.__logger.warning(tape_message(variance=0.85))
        self.__logger.warning(tape_message(variance=0.95))
        self.__logger.tape(tape_message(variance=0.0))
        return {'params': svd, 'eigen_val': eigen_val, 'tot_var': tot_var, 'k_pc': k_pc, 'U_rdd': compute_u}

    def optimal_pca_model(self, df: DataFrame) -> DataFrame:
        k_pc = self.__compute_pc(df)['k_pc']
        pca_features_col = f"{k_pc}_pca_features"
        pca = PCA(k=k_pc, inputCol='scaled_features', outputCol=pca_features_col)
        preorder_columns = ['id', 'features', 'scaled_features', pca_features_col]
        self.__logger.info(f"Set Components Over {self.offset} Of The Variance k={k_pc}")
        return pca.fit(self.vec_scale_df).transform(self.vec_scale_df).select(preorder_columns)

    def _transform(self, dataset: DataFrame):
        return self.optimal_pca_model(df=dataset)


class IndependentComponent:
    """
    for ICA algorithm
    """


class LinearDAnalysis:
    """
    for Linear Discriminant Analysis algorithm
    """


class LLinearEmbedding:
    """
    for Locally Linear Embedding Analysis algorithm
    """


class StochasticNeighbor:
    """
    for t-distributed Stochastic Neighbor Embedding (t-SNE) algorithm
    """
